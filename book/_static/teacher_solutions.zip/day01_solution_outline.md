# Day 01 solution outline
- Kiểm tra số bệnh nhân, số cột, biến đích.
- Tạo Table 1 toàn cohort và theo nhóm EGFR.
- Xuất tối thiểu 3 hình: age histogram, tumor size boxplot, sex bar chart.
- Viết 3–5 dòng diễn giải thận trọng, chưa kết luận nhân quả.
