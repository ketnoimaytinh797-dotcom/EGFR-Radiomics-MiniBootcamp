# Day 03 solution outline
- Chạy 5-fold CV cho ROI chính.
- Tính bootstrap CI cho AUC.
- Làm một ví dụ leakage để học sinh thấy sự khác biệt giữa cách làm đúng và sai.
