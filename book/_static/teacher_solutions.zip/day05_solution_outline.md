# Day 05 solution outline
- Ghép toàn bộ flow thành một notebook capstone.
- Xuất bảng, hình và notes_summary.txt.
- Kiểm tra tên file output trước khi dùng cho báo cáo hoặc poster.
