# Day 02 solution outline
- So sánh intra, ring1, ring3, ring5 trên cùng train/test split.
- Báo cáo ROC AUC, sensitivity, specificity, confusion matrix.
- Nhấn mạnh một lần split chỉ là minh họa, chưa phải kết luận cuối cùng.
