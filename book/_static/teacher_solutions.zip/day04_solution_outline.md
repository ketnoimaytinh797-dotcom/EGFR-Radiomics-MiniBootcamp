# Day 04 solution outline
- Tạo predicted probability cho subset NGS.
- Tính delta mean P và delta median P theo pathway.
- Dùng median song song với mean vì cỡ mẫu nhỏ và phân bố có thể lệch.
